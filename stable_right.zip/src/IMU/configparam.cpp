#include "configparam.h"

namespace dso_vi
{
double ConfigParam::_g = 9.810;

Eigen::Matrix4d ConfigParam::_EigTbc = Eigen::Matrix4d::Identity();
cv::Mat ConfigParam::_MatTbc = cv::Mat::eye(4,4,CV_32F);
Eigen::Matrix4d ConfigParam::_EigTcb = Eigen::Matrix4d::Identity();
cv::Mat ConfigParam::_MatTcb = cv::Mat::eye(4,4,CV_32F);

int ConfigParam::_LocalWindowSize = 10;
double ConfigParam::_ImageDelayToIMU = 0;
bool ConfigParam::_bAccMultiply9p8 = false;
double ConfigParam::_nVINSInitTime = 15;

Eigen::Vector3d ConfigParam::_EigAccBias = Eigen::Vector3d::Zero();
cv::Mat ConfigParam::_MatAccBias = cv::Mat::zeros(3, 1, CV_32F);

Eigen::Vector3d ConfigParam::_EigGyroBias = Eigen::Vector3d::Zero();
cv::Mat ConfigParam::_MatGyroBias = cv::Mat::zeros(3, 1, CV_32F);

bool ConfigParam::addprior = true;
bool ConfigParam::addimu = true;
double ConfigParam::accel_noise_sigma = 2.0e-2;
double ConfigParam::gyro_noise_sigma = 2.0e-4;
double ConfigParam::accel_bias_rw_sigma = 5e-3;
double ConfigParam::gyro_bias_rw_sigma = 2e-4;

ConfigParam::ConfigParam(std::string configfile)
{
    cv::FileStorage fSettings(configfile, cv::FileStorage::READ);

    std::cout<<std::endl<<std::endl<<"Parameters: "<<std::endl;

    _testDiscardTime = fSettings["test.DiscardTime"];
    _nVINSInitTime = fSettings["test.VINSInitTime"];
    std::cout<<"VINS initialize time: "<<_nVINSInitTime<<std::endl;
    std::cout<<"Discart time in test data: "<<_testDiscardTime<<std::endl;

    fSettings["bagfile"] >> _bagfile;
    std::cout<<"open rosbag: "<<_bagfile<<std::endl;
    fSettings["imutopic"] >> _imuTopic;
    fSettings["imagetopic"] >> _imageTopic;
    std::cout<<"imu topic: "<<_imuTopic<<std::endl;
    std::cout<<"image topic: "<<_imageTopic<<std::endl;

    _LocalWindowSize = fSettings["LocalMapping.LocalWindowSize"];
    std::cout<<"local window size: "<<_LocalWindowSize<<std::endl;

    _ImageDelayToIMU = fSettings["Camera.delaytoimu"];
    std::cout<<"timestamp image delay to imu: "<<_ImageDelayToIMU<<std::endl;



    accel_noise_sigma = fSettings["accel_noise_sigma"];
    gyro_noise_sigma = fSettings["gyro_noise_sigma"];
    accel_bias_rw_sigma = fSettings["accel_bias_rw_sigma"];
    gyro_bias_rw_sigma = fSettings["gyro_bias_rw_sigma"];



    {
        cv::FileNode Tbc_ = fSettings["Camera.Tbc"];
        Eigen::Matrix<double,3,3> R;
        R << Tbc_[0], Tbc_[1], Tbc_[2],
                Tbc_[4], Tbc_[5], Tbc_[6],
                Tbc_[8], Tbc_[9], Tbc_[10];
        Eigen::Quaterniond qr(R);
        R = qr.normalized().toRotationMatrix();
        Eigen::Matrix<double,3,1> t( Tbc_[3], Tbc_[7], Tbc_[11]);
        _EigTbc = Eigen::Matrix4d::Identity();
        _EigTbc.block<3,3>(0,0) = R;
        _EigTbc.block<3,1>(0,3) = t;
        _MatTbc = cv::Mat::eye(4,4,CV_32F);
        for(int i=0;i<4;i++)
            for(int j=0;j<4;j++)
                _MatTbc.at<float>(i,j) = _EigTbc(i,j);

        _EigTcb = Eigen::Matrix4d::Identity();
        _EigTcb.block<3,3>(0,0) = R.transpose();
        _EigTcb.block<3,1>(0,3) = -R.transpose()*t;
        for(int i=0;i<4;i++)
            for(int j=0;j<4;j++)
                _MatTcb.at<float>(i,j) = _EigTcb(i,j);

        // Tbc_[0], Tbc_[1], Tbc_[2], Tbc_[3], Tbc_[4], Tbc_[5], Tbc_[6], Tbc_[7], Tbc_[8], Tbc_[9], Tbc_[10], Tbc_[11], Tbc_[12], Tbc_[13], Tbc_[14], Tbc_[15];
        std::cout<<"Tbc inited:"<<std::endl<<_EigTbc<<std::endl<<_MatTbc<<std::endl;
        std::cout<<"Tcb inited:"<<std::endl<<_EigTcb<<std::endl<<_MatTcb<<std::endl;
        std::cout<<"Tbc*Tcb:"<<std::endl<<_EigTbc*_EigTcb<<std::endl<<_MatTbc*_MatTcb<<std::endl;
    }

    {
        int tmpBool = fSettings["IMU.multiplyG"];
        _bAccMultiply9p8 = (tmpBool != 0);
        std::cout<<"whether acc*9.8? 0/1: "<<_bAccMultiply9p8<<std::endl;
    }

    {
        int tmpBool = fSettings["addprior"];
        addprior = (tmpBool != 0);
        std::cout<<"whether add prior? 0/1: "<<addprior<<std::endl;
    }

    {
        int tmpBool = fSettings["addimu"];
        addimu = (tmpBool != 0);
        if (addprior == true) {
            addimu = true;
        }
        std::cout<<"whether add imu? 0/1: "<<addimu<<std::endl;
    }


    // acc bias
    cv::FileNode accBias_ = fSettings["IMU.accBias"];
    if ( !accBias_.isNone() && (accBias_.size() == 3) )
    {
        _EigAccBias << accBias_[0], accBias_[1], accBias_[2];
        _MatAccBias = cv::Mat::zeros(3, 1, CV_32F);
        for (int i = 0; i < 3; i++)
        {
            _MatAccBias.at<float>(i, 0) = _EigAccBias(i);
        }

        std::cout << "Acc Bias: " << _EigAccBias.transpose() << std::endl;
    }
    else
    {
        std::cerr << "Accelerometer bias not in config: setting to zero!!!!" << std::endl;
        _EigAccBias = Eigen::Vector3d::Zero();
        _MatAccBias = cv::Mat::zeros(3, 1, CV_32F);
    }

    // gyro bias
    cv::FileNode gyroBias_ = fSettings["IMU.gyroBias"];
    if ( !gyroBias_.isNone() && (gyroBias_.size() == 3) )
    {
        _EigGyroBias << gyroBias_[0], gyroBias_[1], gyroBias_[2];
        _MatGyroBias = cv::Mat::zeros(3, 1, CV_32F);
        for (int i = 0; i < 3; i++)
        {
            _MatGyroBias.at<float>(i, 0) = _EigGyroBias(i);
        }

        std::cout << "Gyro Bias: " << _EigGyroBias.transpose() << std::endl;
    }
    else
    {
        std::cerr << "Gyroscope bias not in config: setting to zero!!!!" << std::endl;
        _EigGyroBias = Eigen::Vector3d::Zero();
        _MatGyroBias = cv::Mat::zeros(3, 1, CV_32F);
    }
}


Eigen::Matrix4d ConfigParam::GetEigTbc()
{
    return _EigTbc;
}

cv::Mat ConfigParam::GetMatTbc()
{
    return _MatTbc.clone();
}

Eigen::Matrix4d ConfigParam::GetEigT_cb()
{
    return _EigTcb;
}

cv::Mat ConfigParam::GetMatT_cb()
{
    return _MatTcb.clone();
}

int ConfigParam::GetLocalWindowSize()
{
    return _LocalWindowSize;
}

double ConfigParam::GetImageDelayToIMU()
{
    return _ImageDelayToIMU;
}

bool ConfigParam::GetAccMultiply9p8()
{
    return _bAccMultiply9p8;
}

double ConfigParam::Getaccel_noise_sigma()
{
    return accel_noise_sigma;
}

double ConfigParam::Getgyro_noise_sigma(){
    return gyro_noise_sigma;
}

double ConfigParam::Getaccel_bias_rw_sigma()
{
    return accel_bias_rw_sigma;
}

double ConfigParam::Getgyro_bias_rw_sigma(){
    return gyro_bias_rw_sigma;
}

bool ConfigParam::Getaddprior()
{
    return addprior;
}

bool ConfigParam::Getaddimu(){
    return addimu;
}

cv::Mat ConfigParam::GetMatAccBias()
{
    return _MatAccBias;
}

Eigen::Vector3d ConfigParam::GetEigAccBias()
{
    return _EigAccBias;
}

cv::Mat ConfigParam::GetMatGyroBias()
{
    return _MatGyroBias;
}

Eigen::Vector3d ConfigParam::GetEigGyroBias()
{
    return _EigGyroBias;
}

}
